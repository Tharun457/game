import { useEffect, useState } from 'react';
import { View, StyleSheet, Dimensions, Text, TouchableOpacity } from 'react-native';
import { GameEngine } from 'react-native-game-engine';
import Animated, {
  useAnimatedStyle,
  withSpring,
  useSharedValue,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';

const GAME_WIDTH = Dimensions.get('window').width;
const GAME_HEIGHT = Dimensions.get('window').height;
const LANE_WIDTH = GAME_WIDTH / 3;
const PLAYER_SIZE = 50;

const Player = ({ position, isJumping }) => {
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: position.value },
        { translateY: isJumping.value },
      ],
    };
  });

  return (
    <Animated.View
      style={[
        styles.player,
        animatedStyle,
      ]}
    />
  );
};

const Obstacle = ({ position }) => {
  return (
    <Animated.View
      style={[
        styles.obstacle,
        {
          transform: [{ translateY: position }],
        },
      ]}
    />
  );
};

export default function Game() {
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const playerPosition = useSharedValue(GAME_WIDTH / 2 - PLAYER_SIZE / 2);
  const playerJump = useSharedValue(0);
  const [obstacles, setObstacles] = useState([]);

  const panGesture = Gesture.Pan()
    .onUpdate((event) => {
      const newPosition = Math.max(
        0,
        Math.min(GAME_WIDTH - PLAYER_SIZE, playerPosition.value + event.translationX)
      );
      playerPosition.value = newPosition;
    });

  const tapGesture = Gesture.Tap()
    .onStart(() => {
      if (playerJump.value === 0) {
        playerJump.value = withSequence(
          withSpring(-100),
          withTiming(0, { duration: 500 })
        );
      }
    });

  const composed = Gesture.Simultaneous(panGesture, tapGesture);

  useEffect(() => {
    if (isGameOver) return;

    const gameLoop = setInterval(() => {
      setScore((prev) => prev + 1);
      
      // Spawn new obstacles
      if (Math.random() < 0.05) {
        setObstacles((prev) => [
          ...prev,
          {
            id: Date.now(),
            x: Math.floor(Math.random() * 3) * LANE_WIDTH + LANE_WIDTH / 2 - 25,
            y: -50,
          },
        ]);
      }

      // Move obstacles
      setObstacles((prev) =>
        prev
          .map((obstacle) => ({
            ...obstacle,
            y: obstacle.y + 5,
          }))
          .filter((obstacle) => obstacle.y < GAME_HEIGHT)
      );
    }, 16);

    return () => clearInterval(gameLoop);
  }, [isGameOver]);

  const restartGame = () => {
    setScore(0);
    setIsGameOver(false);
    setObstacles([]);
    playerPosition.value = GAME_WIDTH / 2 - PLAYER_SIZE / 2;
  };

  return (
    <View style={styles.container}>
      <View style={styles.scoreContainer}>
        <Text style={styles.scoreText}>Score: {score}</Text>
      </View>

      <GestureDetector gesture={composed}>
        <View style={styles.gameContainer}>
          <Player position={playerPosition} isJumping={playerJump} />
          {obstacles.map((obstacle) => (
            <Obstacle
              key={obstacle.id}
              position={obstacle.y}
              style={{ left: obstacle.x }}
            />
          ))}
        </View>
      </GestureDetector>

      {isGameOver && (
        <View style={styles.gameOverContainer}>
          <Text style={styles.gameOverText}>Game Over!</Text>
          <Text style={styles.finalScoreText}>Final Score: {score}</Text>
          <TouchableOpacity style={styles.restartButton} onPress={restartGame}>
            <Text style={styles.restartButtonText}>Play Again</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2c3e50',
  },
  gameContainer: {
    flex: 1,
    position: 'relative',
  },
  player: {
    width: PLAYER_SIZE,
    height: PLAYER_SIZE,
    backgroundColor: '#e74c3c',
    borderRadius: 25,
    position: 'absolute',
    bottom: 100,
  },
  obstacle: {
    width: 50,
    height: 50,
    backgroundColor: '#3498db',
    position: 'absolute',
    borderRadius: 10,
  },
  scoreContainer: {
    padding: 20,
    alignItems: 'center',
  },
  scoreText: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
  },
  gameOverContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  gameOverText: {
    fontSize: 48,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 20,
  },
  finalScoreText: {
    fontSize: 24,
    color: '#fff',
    marginBottom: 30,
  },
  restartButton: {
    backgroundColor: '#2ecc71',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 10,
  },
  restartButtonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
});