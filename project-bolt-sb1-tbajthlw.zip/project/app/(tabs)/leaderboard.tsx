import { View, Text, StyleSheet, FlatList } from 'react-native';

const dummyLeaderboard = [
  { id: '1', name: 'Player 1', score: 1500 },
  { id: '2', name: 'Player 2', score: 1200 },
  { id: '3', name: 'Player 3', score: 1000 },
  { id: '4', name: 'Player 4', score: 800 },
  { id: '5', name: 'Player 5', score: 600 },
];

export default function Leaderboard() {
  const renderItem = ({ item, index }) => (
    <View style={styles.leaderboardItem}>
      <Text style={styles.rank}>#{index + 1}</Text>
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.score}>{item.score}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Leaderboard</Text>
      <FlatList
        data={dummyLeaderboard}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2c3e50',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginVertical: 20,
  },
  listContainer: {
    padding: 10,
  },
  leaderboardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#34495e',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  rank: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#e74c3c',
    width: 50,
  },
  name: {
    flex: 1,
    fontSize: 18,
    color: '#fff',
  },
  score: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2ecc71',
  },
});